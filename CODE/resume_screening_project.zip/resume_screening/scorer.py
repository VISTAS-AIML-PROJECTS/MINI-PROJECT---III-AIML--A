"""Modules 3,4,5,7,8 - skills/education/experience extraction, TF-IDF similarity,
transparent score and ranking (Sections V and VI of the paper)."""
import re
from datetime import date
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from skills import SKILLS, ALIASES
from preprocess import clean_text, for_tfidf, anonymize

# Paper Sec. V-B: weights are experimental settings, not a universal hiring rule
WEIGHTS = {"skill": 0.50, "experience": 0.20, "education": 0.15, "similarity": 0.15}

EDU_LEVELS = {
    4: [r"\bph\.?d\b", r"\bdoctorate\b"],
    3: [r"\bm\.?tech\b", r"\bm\.?e\b", r"\bm\.?sc\b", r"\bmca\b", r"\bmba\b",
        r"\bmaster'?s?\b", r"\bpost.?graduate\b"],
    2: [r"\bb\.?tech\b", r"\bb\.?e\b", r"\bb\.?sc\b", r"\bbca\b", r"\bb\.?com\b",
        r"\bbachelor'?s?\b", r"\bundergraduate\b", r"\bdegree\b"],
    1: [r"\bdiploma\b", r"\bpolytechnic\b"],
}
EDU_NAMES = {4: "PhD", 3: "Master's", 2: "Bachelor's", 1: "Diploma", 0: "Not found"}


# ---------- skills ----------
def _skill_pattern(skill):
    forms = [skill] + ALIASES.get(skill, [])
    alt = "|".join(re.escape(f) for f in forms)
    return re.compile(r"(?<![a-z0-9+#.])(" + alt + r")(?![a-z0-9+#])")


_PATTERNS = {s: _skill_pattern(s) for s in SKILLS}


def find_skills(text):
    t = clean_text(text)
    return {s for s, p in _PATTERNS.items() if p.search(t)}


# ---------- education ----------
def education_level(text):
    t = text.lower()
    best = 0
    for level, pats in EDU_LEVELS.items():
        if any(re.search(p, t) for p in pats):
            best = max(best, level)
    return best


# ---------- experience ----------
def experience_years(text):
    """Largest of: explicit 'N years' statements, or sum of date ranges (2019 - 2022 / Present)."""
    t = text.lower()
    explicit = [float(x) for x in re.findall(r"(\d+(?:\.\d+)?)\s*\+?\s*(?:years|yrs|year)", t)]
    ranges = 0.0
    for a, b in re.findall(r"((?:19|20)\d{2})\s*(?:-|to|\u2013)\s*((?:19|20)\d{2}|present|current|now)", t):
        start = int(a)
        end = date.today().year if b in ("present", "current", "now") else int(b)
        if 0 <= end - start <= 40:
            ranges += end - start
    return max(max(explicit, default=0.0), ranges)


def required_years(jd_text):
    m = re.findall(r"(\d+)\s*\+?\s*(?:years|yrs|year)", jd_text.lower())
    return float(min(map(int, m))) if m else 0.0


# ---------- scoring ----------
def similarity_scores(resume_texts, jd_text):
    """TF-IDF fitted on all documents, cosine similarity resume<->JD (Sec. VI-B/C)."""
    docs = [for_tfidf(jd_text)] + [for_tfidf(r) for r in resume_texts]
    vec = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True)
    X = vec.fit_transform(docs)
    return cosine_similarity(X[0:1], X[1:]).ravel()


def score_one(resume_text, jd_text, sim):
    jd_skills = find_skills(jd_text)
    r_skills = find_skills(resume_text)
    matched = sorted(jd_skills & r_skills)
    missing = sorted(jd_skills - r_skills)
    skill = len(matched) / len(jd_skills) if jd_skills else 0.0

    r_years, req = experience_years(resume_text), required_years(jd_text)
    exp = min(r_years / req, 1.0) if req > 0 else (1.0 if r_years > 0 else 0.5)

    r_edu, req_edu = education_level(resume_text), education_level(jd_text)
    edu = min(r_edu / req_edu, 1.0) if req_edu > 0 else (1.0 if r_edu > 0 else 0.5)

    final = (WEIGHTS["skill"] * skill + WEIGHTS["experience"] * exp
             + WEIGHTS["education"] * edu + WEIGHTS["similarity"] * float(sim))
    return {
        "skill_match": round(skill * 100, 1),
        "experience_match": round(exp * 100, 1),
        "education_match": round(edu * 100, 1),
        "text_similarity": round(float(sim) * 100, 1),
        "final_score": round(final * 100, 1),
        "matched_skills": matched,
        "missing_skills": missing,
        "experience_years": r_years,
        "education": EDU_NAMES[r_edu],
    }


def screen_resumes(resumes, jd_text):
    """resumes: dict {file_name: text}. Returns list of results sorted by score (Sec. VI-D)."""
    names = list(resumes)
    texts = [anonymize(resumes[n]) for n in names]       # privacy: strip contact/gender terms
    sims = similarity_scores(texts, jd_text)
    results = []
    for n, t, s in zip(names, texts, sims):
        r = score_one(t, jd_text, s)
        r["candidate"] = n
        results.append(r)
    results.sort(key=lambda r: r["final_score"], reverse=True)
    for i, r in enumerate(results, 1):
        r["rank"] = i
    return results


def bias_check(resume_text, jd_text):
    """Sec. VII-E: score with vs without anonymisation; a big gap = suspicious."""
    raw = score_one(resume_text, jd_text, similarity_scores([resume_text], jd_text)[0])
    anon_t = anonymize(resume_text)
    anon = score_one(anon_t, jd_text, similarity_scores([anon_t], jd_text)[0])
    return raw["final_score"], anon["final_score"]
