"""Quick terminal test (no Streamlit needed):  python demo.py"""
import glob, os
from extractor import extract_text
from scorer import screen_resumes

jd = open("sample_data/job_description.txt", encoding="utf-8").read()
resumes = {os.path.basename(p): extract_text(p) for p in sorted(glob.glob("sample_data/resume_*.txt"))}
for r in screen_resumes(resumes, jd):
    print(f"#{r['rank']} {r['candidate']:<22} score={r['final_score']:>5}  "
          f"skill={r['skill_match']}  exp={r['experience_match']}  edu={r['education_match']}  "
          f"sim={r['text_similarity']}")
    print("    matched:", ", ".join(r["matched_skills"]))
    print("    missing:", ", ".join(r["missing_skills"]) or "-")
