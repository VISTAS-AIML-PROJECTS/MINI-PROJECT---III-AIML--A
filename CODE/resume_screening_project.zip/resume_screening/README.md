# AI-Based Job Resume Screening System

Implements the base paper: PDF/DOCX text extraction -> cleaning -> skill/education/experience
extraction -> TF-IDF + cosine similarity -> transparent weighted score -> ranking
(+ optional SVM role classifier, SQLite storage, Streamlit UI, bias check).

## Setup (VS Code terminal)
    python -m venv venv
    venv\Scripts\activate          # Windows   (Mac/Linux: source venv/bin/activate)
    pip install -r requirements.txt

## Run
    python demo.py                 # terminal test with sample_data
    streamlit run app.py           # web interface

## Optional: train the SVM (needs a labelled CSV with columns Resume, Category)
    python classifier.py UpdatedResumeDataSet.csv
A free dataset: search "Resume Dataset" (UpdatedResumeDataSet.csv) on Kaggle.
This creates role_model.joblib; the app then shows a predicted role automatically.

## Files
| File | Paper module |
|---|---|
| extractor.py | Text module (PDF/DOCX/TXT) |
| preprocess.py | Cleaning, stop-words, anonymisation |
| skills.py | Skill dictionary (edit/extend) |
| scorer.py | NLP, feature, matching, scoring, ranking modules |
| classifier.py | SVM classification module |
| database.py | SQLite candidate/job/screening records |
| app.py | Result interface |

Score = 0.50 Skill + 0.20 Experience + 0.15 Education + 0.15 Text similarity
(weights are experimental - change them in scorer.py and report what you tested).
