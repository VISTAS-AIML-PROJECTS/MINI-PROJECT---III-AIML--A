"""Streamlit interface (Fig. 5 of the paper).  Run:  streamlit run app.py"""
import pandas as pd
import streamlit as st

from extractor import extract_text
from scorer import screen_resumes, bias_check
from classifier import predict_role
from database import save_results, history

st.set_page_config(page_title="AI Resume Screening", layout="wide")
st.title("AI-Based Job Resume Screening System")
st.caption("Decision support only - a recruiter must review the original resume.")

col1, col2 = st.columns(2)
with col1:
    title = st.text_input("Job title", "Python Developer")
    jd_text = st.text_area("Paste job description", height=220,
                           placeholder="Required skills: Python, SQL, Flask...\n2+ years experience, B.E/B.Tech")
with col2:
    files = st.file_uploader("Upload resumes (PDF / DOCX / TXT)",
                             type=["pdf", "docx", "txt"], accept_multiple_files=True)

if st.button("Screen candidates", type="primary"):
    if not jd_text.strip() or not files:
        st.warning("Please add a job description and at least one resume.")
        st.stop()

    resumes, errors = {}, []
    for f in files:
        try:
            resumes[f.name] = extract_text(f, f.name)
        except Exception as e:                     # show failures, don't hide them
            errors.append(f"{f.name}: {e}")
    for e in errors:
        st.error(e)
    if not resumes:
        st.stop()

    results = screen_resumes(resumes, jd_text)
    for r in results:
        r["role"] = predict_role(resumes[r["candidate"]]) or "-"
    save_results(title, jd_text, results)

    st.subheader("Ranking")
    df = pd.DataFrame([{
        "Rank": r["rank"], "Candidate": r["candidate"], "Overall /100": r["final_score"],
        "Skill %": r["skill_match"], "Experience %": r["experience_match"],
        "Education %": r["education_match"], "Similarity %": r["text_similarity"],
        "Predicted role": r["role"]} for r in results])
    st.dataframe(df, use_container_width=True, hide_index=True)
    st.bar_chart(df.set_index("Candidate")["Overall /100"])

    st.subheader("Explanation per candidate")
    for r in results:
        with st.expander(f"#{r['rank']}  {r['candidate']}  -  {r['final_score']}/100"):
            a, b, c, d = st.columns(4)
            a.metric("Skill match", f"{r['skill_match']}%")
            b.metric("Experience", f"{r['experience_match']}%")
            c.metric("Education", f"{r['education_match']}%")
            d.metric("Text similarity", f"{r['text_similarity']}%")
            st.write("**Matched skills:**", ", ".join(r["matched_skills"]) or "none")
            st.write("**Missing skills:**", ", ".join(r["missing_skills"]) or "none")
            st.write(f"**Detected experience:** {r['experience_years']:.0f} yrs | "
                     f"**Education:** {r['education']}")
            raw, anon = bias_check(resumes[r["candidate"]], jd_text)
            st.caption(f"Bias check - score with personal details: {raw}, "
                       f"anonymised: {anon}")
            with st.popover("View extracted resume text"):
                st.text(resumes[r["candidate"]][:3000])

with st.sidebar:
    st.header("Screening history")
    rows = history(20)
    if rows:
        st.dataframe(pd.DataFrame(rows, columns=["Date", "Job", "File", "Score", "Rank"]),
                     hide_index=True)
    else:
        st.write("No records yet.")
