"""Module 2 - Text extraction (PDF / DOCX / TXT)."""
import io
import pdfplumber
import docx


def extract_text(file_or_path, filename=None):
    """Accepts a path string OR a file-like object (e.g. Streamlit upload)."""
    name = (filename or getattr(file_or_path, "name", str(file_or_path))).lower()
    if isinstance(file_or_path, str):
        with open(file_or_path, "rb") as f:
            data = f.read()
    else:
        data = file_or_path.read()

    if name.endswith(".pdf"):
        text = ""
        with pdfplumber.open(io.BytesIO(data)) as pdf:
            for page in pdf.pages:
                text += (page.extract_text() or "") + "\n"
    elif name.endswith(".docx"):
        d = docx.Document(io.BytesIO(data))
        parts = [p.text for p in d.paragraphs]
        for table in d.tables:                      # resumes often use tables
            for row in table.rows:
                parts.extend(cell.text for cell in row.cells)
        text = "\n".join(parts)
    elif name.endswith(".txt"):
        text = data.decode("utf-8", errors="ignore")
    else:
        raise ValueError("Unsupported file type: " + name)

    if len(text.strip()) < 30:
        # paper Sec. X-E: expose extraction failures instead of hiding them
        raise ValueError(f"Could not read text from {name} (scanned PDF? needs OCR).")
    return text
