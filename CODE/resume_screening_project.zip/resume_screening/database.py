"""Module 9 - SQLite storage (Section VII). Stores only what screening needs."""
import json
import sqlite3
from datetime import datetime

DB = "screening.db"


def _conn():
    c = sqlite3.connect(DB)
    c.execute("""CREATE TABLE IF NOT EXISTS job(
        job_id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, description TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS candidate(
        candidate_id INTEGER PRIMARY KEY AUTOINCREMENT, file_name TEXT,
        skills TEXT, education TEXT, experience REAL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS screening(
        id INTEGER PRIMARY KEY AUTOINCREMENT, candidate_id INTEGER, job_id INTEGER,
        match_score REAL, rank INTEGER, matched_skills TEXT, missing_skills TEXT,
        components TEXT, date TEXT)""")
    return c


def save_results(job_title, jd_text, results):
    c = _conn()
    job_id = c.execute("INSERT INTO job(title, description) VALUES(?,?)",
                       (job_title, jd_text)).lastrowid
    for r in results:
        cid = c.execute(
            "INSERT INTO candidate(file_name, skills, education, experience) VALUES(?,?,?,?)",
            (r["candidate"], ", ".join(r["matched_skills"]), r["education"],
             r["experience_years"])).lastrowid
        comps = {k: r[k] for k in ("skill_match", "experience_match",
                                   "education_match", "text_similarity")}
        c.execute(
            "INSERT INTO screening(candidate_id, job_id, match_score, rank, matched_skills,"
            " missing_skills, components, date) VALUES(?,?,?,?,?,?,?,?)",
            (cid, job_id, r["final_score"], r["rank"], ", ".join(r["matched_skills"]),
             ", ".join(r["missing_skills"]), json.dumps(comps),
             datetime.now().isoformat(timespec="seconds")))
    c.commit()
    c.close()


def history(limit=50):
    c = _conn()
    rows = c.execute("""SELECT s.date, j.title, c.file_name, s.match_score, s.rank
                        FROM screening s JOIN candidate c USING(candidate_id)
                        JOIN job j USING(job_id) ORDER BY s.id DESC LIMIT ?""",
                     (limit,)).fetchall()
    c.close()
    return rows
