"""Skill dictionary (Section VI-A of the paper). Add your own terms freely."""

SKILLS = [
    # languages
    "python", "java", "c", "c++", "c#", "javascript", "typescript", "sql", "r",
    "go", "php", "kotlin", "swift", "matlab", "html", "css",
    # data / ML
    "machine learning", "deep learning", "nlp", "natural language processing",
    "computer vision", "data analysis", "data science", "statistics",
    "pandas", "numpy", "scikit-learn", "tensorflow", "keras", "pytorch",
    "spacy", "nltk", "opencv", "tableau", "power bi", "excel", "hadoop", "spark",
    # web / backend
    "django", "flask", "fastapi", "react", "angular", "node.js", "express",
    "rest api", "spring boot", "bootstrap",
    # databases / cloud / tools
    "mysql", "postgresql", "mongodb", "sqlite", "oracle", "redis",
    "aws", "azure", "gcp", "docker", "kubernetes", "git", "github", "linux",
    "jenkins", "ci/cd", "jira",
    # general
    "oop", "data structures", "algorithms", "agile", "scrum", "testing",
    "selenium", "communication", "problem solving", "teamwork",
]

# Different spellings that should count as the same skill
ALIASES = {
    "nlp": ["natural language processing"],
    "natural language processing": ["nlp"],
    "scikit-learn": ["sklearn", "scikit learn"],
    "node.js": ["nodejs", "node js"],
    "power bi": ["powerbi"],
    "postgresql": ["postgres"],
    "machine learning": ["ml"],
    "deep learning": ["dl"],
    "javascript": ["js"],
    "rest api": ["restful api", "rest apis", "restful apis"],
    "oop": ["object oriented programming", "object-oriented programming"],
    "ci/cd": ["cicd"],
}
