"""Module 6 - SVM role classification (Section IV-D). Optional: needs a labelled CSV.

Usage:   python classifier.py data/UpdatedResumeDataSet.csv
CSV needs two columns: 'Resume' (text) and 'Category' (job role).
"""
import sys
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC
from sklearn.metrics import classification_report, accuracy_score

from preprocess import for_tfidf

MODEL_PATH = "role_model.joblib"


def train(csv_path):
    df = pd.read_csv(csv_path).dropna(subset=["Resume", "Category"])
    print("Class distribution:\n", df["Category"].value_counts(), "\n")
    X = df["Resume"].astype(str).map(for_tfidf)
    y = df["Category"]
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y)
    model = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, min_df=2)),
        ("svm", LinearSVC(C=1.0)),
    ])
    model.fit(X_tr, y_tr)
    pred = model.predict(X_te)
    print("Accuracy:", round(accuracy_score(y_te, pred), 4))
    print(classification_report(y_te, pred, zero_division=0))   # precision/recall/F1
    joblib.dump(model, MODEL_PATH)
    print("Saved model ->", MODEL_PATH)


def predict_role(text):
    try:
        model = joblib.load(MODEL_PATH)
    except FileNotFoundError:
        return None
    return model.predict([for_tfidf(text)])[0]


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("Usage: python classifier.py <labelled_resumes.csv>")
    train(sys.argv[1])
