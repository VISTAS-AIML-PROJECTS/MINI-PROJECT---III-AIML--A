"""Module 2/4 - Cleaning & normalisation (Section IV-B)."""
import re
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

# Keep terms that carry meaning even if they look like stop-words/noise
KEEP = {"c", "r", "go"}
STOP = set(ENGLISH_STOP_WORDS) - KEEP

GENDER_WORDS = r"\b(he|she|his|her|him|hers|mr|mrs|ms|miss|male|female|gender|"\
               r"husband|wife|married|single|father|mother)\b"


def clean_text(text):
    """lowercase, normalise whitespace, keep tech symbols (c++, c#, node.js, ci/cd)."""
    text = text.lower()
    text = re.sub(r"[\u2022\u2023\u25cf\u25aa\-\u2013\u2014]+", " ", text)  # bullets/dashes
    text = re.sub(r"[^a-z0-9+#./\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def for_tfidf(text):
    """cleaned text with stop-words removed (used for TF-IDF similarity)."""
    words = [w for w in clean_text(text).split() if w not in STOP and len(w) > 1 or w in KEEP]
    return " ".join(words)


def anonymize(text):
    """Remove emails, phones, URLs and gender-related words (privacy + bias check, Sec. VII-D/E)."""
    text = re.sub(r"\S+@\S+", " ", text)
    text = re.sub(r"(https?://|www\.)\S+", " ", text)
    text = re.sub(r"\+?\d[\d\s\-()]{8,}\d", " ", text)
    text = re.sub(GENDER_WORDS, " ", text, flags=re.I)
    return text
