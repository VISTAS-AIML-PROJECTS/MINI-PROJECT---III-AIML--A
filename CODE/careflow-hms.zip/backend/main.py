from datetime import datetime, timezone
from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select, or_
from sqlalchemy.orm import Session, joinedload
from .database import Base, engine, get_db, settings
from .models import User, Vital, Visit, Prescription
from .schemas import UserCreate, UserOut, LoginRequest, Token, VitalCreate, VitalOut, VisitCreate, VisitOut
from .auth import hash_password, verify_password, create_access_token, get_current_user, require_roles

app = FastAPI(title="Hospital Management System API", version="1.0.0")

origins = [settings.frontend_origin]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/auth/signup", response_model=Token, status_code=201)
def signup(payload: UserCreate, db: Session = Depends(get_db)):
    email = payload.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, "Email is already registered")
    if payload.role == "patient" and (payload.department or payload.specialization):
        raise HTTPException(400, "Department/specialization is only for doctor or staff")
    user = User(
        full_name=payload.full_name.strip(), email=email, password_hash=hash_password(payload.password),
        role=payload.role, age=payload.age, dob=payload.dob, gender=payload.gender,
        blood_group=payload.blood_group, phone=payload.phone, emergency_contact=payload.emergency_contact,
        department=payload.department if payload.role in ("doctor", "staff") else None,
        specialization=payload.specialization if payload.role == "doctor" else None,
    )
    db.add(user); db.commit(); db.refresh(user)
    return Token(access_token=create_access_token(user.id), user=user)

@app.post("/auth/login", response_model=Token)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == payload.email.lower()))
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")
    return Token(access_token=create_access_token(user.id), user=user)

@app.get("/auth/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)):
    return user

def ensure_vital_owner(vital: Vital, user: User):
    if user.role == "patient" and vital.patient_id != user.id:
        raise HTTPException(403, "You can only access your own vitals")

@app.get("/vitals", response_model=list[VitalOut])
def list_vitals(
    limit: int = Query(30, ge=1, le=200),
    patient_id: int | None = Query(None),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    target = user.id if user.role == "patient" else (patient_id or user.id)
    stmt = select(Vital).where(Vital.patient_id == target).order_by(Vital.recorded_at.desc()).limit(limit)
    return list(db.scalars(stmt).all())

@app.post("/vitals", response_model=VitalOut, status_code=201)
def create_vital(payload: VitalCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role != "patient":
        raise HTTPException(403, "Only patients can create their own vital readings")
    vital = Vital(patient_id=user.id, **payload.model_dump(exclude_none=True))
    db.add(vital); db.commit(); db.refresh(vital)
    return vital

@app.put("/vitals/{vital_id}", response_model=VitalOut)
def update_vital(vital_id: int, payload: VitalCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    vital = db.get(Vital, vital_id)
    if not vital: raise HTTPException(404, "Vital reading not found")
    ensure_vital_owner(vital, user)
    if user.role != "patient": raise HTTPException(403, "Only patients can update vitals")
    for k, v in payload.model_dump(exclude_none=True).items(): setattr(vital, k, v)
    db.commit(); db.refresh(vital)
    return vital

@app.delete("/vitals/{vital_id}", status_code=204)
def delete_vital(vital_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    vital = db.get(Vital, vital_id)
    if not vital: raise HTTPException(404, "Vital reading not found")
    ensure_vital_owner(vital, user)
    if user.role != "patient": raise HTTPException(403, "Only patients can delete vitals")
    db.delete(vital); db.commit()

def visit_to_schema(visit: Visit):
    return VisitOut(
        id=visit.id, patient_id=visit.patient_id, doctor_id=visit.doctor_id, visit_date=visit.visit_date,
        department=visit.department, chief_complaint=visit.chief_complaint, diagnosis=visit.diagnosis,
        lab_tests_ordered=visit.lab_tests_ordered, prescriptions=visit.prescriptions,
        doctor_name=visit.doctor.full_name if visit.doctor else None
    )

@app.get("/visits", response_model=list[VisitOut])
def list_visits(
    search: str | None = Query(None),
    start_date: datetime | None = Query(None),
    end_date: datetime | None = Query(None),
    patient_id: int | None = Query(None),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    stmt = select(Visit).options(joinedload(Visit.doctor), joinedload(Visit.prescriptions)).order_by(Visit.visit_date.desc())
    if user.role == "patient":
        stmt = stmt.where(Visit.patient_id == user.id)
    elif patient_id:
        stmt = stmt.where(Visit.patient_id == patient_id)
    if search:
        term = f"%{search}%"
        stmt = stmt.join(Visit.doctor, isouter=True).where(
            or_(Visit.department.ilike(term), Visit.chief_complaint.ilike(term),
                Visit.diagnosis.ilike(term), User.full_name.ilike(term))
        )
    if start_date: stmt = stmt.where(Visit.visit_date >= start_date)
    if end_date: stmt = stmt.where(Visit.visit_date <= end_date)
    return [visit_to_schema(v) for v in db.scalars(stmt).unique().all()]

@app.post("/visits", response_model=VisitOut, status_code=201)
def create_visit(payload: VisitCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role not in ("doctor", "staff"):
        raise HTTPException(403, "Only doctors or staff can create clinical visits")
    patient_id = payload.patient_id
    if not patient_id or not db.get(User, patient_id):
        raise HTTPException(400, "A valid patient_id is required")
    if payload.doctor_id:
        doctor = db.get(User, payload.doctor_id)
        if not doctor or doctor.role != "doctor":
            raise HTTPException(400, "doctor_id must reference a doctor")
    visit = Visit(
        patient_id=patient_id, doctor_id=payload.doctor_id or (user.id if user.role == "doctor" else None),
        visit_date=payload.visit_date or datetime.now(timezone.utc),
        department=payload.department, chief_complaint=payload.chief_complaint,
        diagnosis=payload.diagnosis, lab_tests_ordered=payload.lab_tests_ordered,
    )
    visit.prescriptions = [Prescription(**p.model_dump()) for p in payload.prescriptions]
    db.add(visit); db.commit(); db.refresh(visit)
    return visit_to_schema(visit)

@app.delete("/visits/{visit_id}", status_code=204)
def delete_visit(visit_id: int, user: User = Depends(require_roles("doctor", "staff")), db: Session = Depends(get_db)):
    visit = db.get(Visit, visit_id)
    if not visit: raise HTTPException(404, "Visit not found")
    db.delete(visit); db.commit()

@app.get("/patients", response_model=list[UserOut])
def list_patients(user: User = Depends(require_roles("doctor", "staff")), db: Session = Depends(get_db)):
    return list(db.scalars(select(User).where(User.role == "patient").order_by(User.full_name)).all())
