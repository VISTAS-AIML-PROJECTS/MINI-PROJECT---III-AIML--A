from datetime import datetime
from typing import Literal
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

Role = Literal["patient", "doctor", "staff"]

class UserCreate(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    role: Role
    age: int | None = Field(default=None, ge=0, le=120)
    dob: str | None = None
    gender: str | None = Field(default=None, max_length=30)
    blood_group: str | None = Field(default=None, max_length=10)
    phone: str | None = Field(default=None, max_length=30)
    emergency_contact: str | None = Field(default=None, max_length=120)
    department: str | None = Field(default=None, max_length=120)
    specialization: str | None = Field(default=None, max_length=120)

class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    full_name: str
    email: EmailStr
    role: Role
    age: int | None
    dob: str | None
    gender: str | None
    blood_group: str | None
    phone: str | None
    emergency_contact: str | None
    department: str | None
    specialization: str | None

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class VitalBase(BaseModel):
    recorded_at: datetime | None = None
    weight_kg: float | None = Field(default=None, gt=0, le=500)
    height_cm: float | None = Field(default=None, gt=0, le=300)
    systolic: int | None = Field(default=None, ge=40, le=300)
    diastolic: int | None = Field(default=None, ge=20, le=200)
    fasting_sugar: float | None = Field(default=None, ge=0, le=1000)
    post_prandial_sugar: float | None = Field(default=None, ge=0, le=1000)
    heart_rate: int | None = Field(default=None, ge=20, le=250)
    spo2: float | None = Field(default=None, ge=0, le=100)

class VitalCreate(VitalBase):
    pass

class VitalOut(VitalBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    patient_id: int

class PrescriptionCreate(BaseModel):
    medication_name: str = Field(min_length=1, max_length=160)
    dosage: str | None = Field(default=None, max_length=80)
    frequency: str | None = Field(default=None, max_length=80)

class PrescriptionOut(PrescriptionCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    visit_id: int

class VisitCreate(BaseModel):
    visit_date: datetime | None = None
    patient_id: int | None = None
    doctor_id: int | None = None
    department: str | None = Field(default=None, max_length=120)
    chief_complaint: str | None = None
    diagnosis: str | None = None
    lab_tests_ordered: str | None = None
    prescriptions: list[PrescriptionCreate] = []

class VisitOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    patient_id: int
    doctor_id: int | None
    visit_date: datetime
    department: str | None
    chief_complaint: str | None
    diagnosis: str | None
    lab_tests_ordered: str | None
    prescriptions: list[PrescriptionOut]
    doctor_name: str | None = None
