# CareFlow Hospital Management System

FastAPI + SQLAlchemy + SQLite + Pydantic v2 backend and React/Vite + Tailwind CSS frontend.

## Backend

```bash
cd backend
python -m venv .venv
# Windows PowerShell:
.\.venv\Scripts\Activate.ps1
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env
# macOS/Linux: cp .env.example .env
uvicorn main:app --reload
```

If importing as a package gives import errors, run from the project root with:
`uvicorn backend.main:app --reload`

API docs: http://127.0.0.1:8000/docs

For production, set a strong SECRET_KEY, use HTTPS, restrict CORS, run migrations (Alembic), and use a managed database.

## Frontend

```bash
cd frontend
npm install
copy .env.example .env
# macOS/Linux: cp .env.example .env
npm run dev
```

Open http://localhost:5173.

## Notes

- JWT is stored in `sessionStorage` to reduce persistence after the browser session. For a higher-security production deployment, prefer short-lived access tokens plus secure, HttpOnly, SameSite refresh-token cookies.
- Patients can create/read/update/delete only their own vitals.
- Doctors/staff can create clinical visits and see patient lists.
- SQLite is suitable for development/small deployments. Add Alembic migrations and PostgreSQL for larger production deployments.
- The signup endpoint intentionally supports all three roles for a self-contained demo. In a real hospital, doctor/staff role creation should be restricted to administrators.
