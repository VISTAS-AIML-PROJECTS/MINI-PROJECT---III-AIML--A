import { useEffect, useState } from "react";
import { Navigate, NavLink, Route, Routes, useNavigate } from "react-router-dom";
import { Activity, ClipboardList, HeartPulse, LogOut, UserRound } from "lucide-react";
import api from "./api";
import AuthPage from "./pages/AuthPage";
import DashboardPage from "./pages/DashboardPage";
import HistoryPage from "./pages/HistoryPage";

export default function App() {
  const [user, setUser] = useState(() => {
    const raw = sessionStorage.getItem("hms_user"); return raw ? JSON.parse(raw) : null;
  });
  const navigate = useNavigate();
  const login = (data) => { sessionStorage.setItem("hms_token", data.access_token); sessionStorage.setItem("hms_user", JSON.stringify(data.user)); setUser(data.user); navigate("/"); };
  const logout = () => { sessionStorage.clear(); setUser(null); navigate("/login"); };
  useEffect(() => { if (user) api.get("/auth/me").catch(logout); }, []);
  if (!user) return <Routes><Route path="*" element={<AuthPage onLogin={login}/>} /></Routes>;
  return <div className="min-h-screen bg-slate-50 text-slate-900">
    <aside className="fixed inset-y-0 left-0 hidden w-64 border-r bg-white p-5 md:block">
      <div className="flex items-center gap-2 text-xl font-bold text-teal-700"><HeartPulse/> CareFlow HMS</div>
      <p className="mt-1 text-xs text-slate-400">Clinical operations</p>
      <nav className="mt-8 space-y-2">
        <NavLink to="/" className={({isActive})=>`flex items-center gap-3 rounded-xl px-4 py-3 ${isActive?"bg-teal-50 text-teal-700":"text-slate-600 hover:bg-slate-50"}`}><Activity size={18}/>Dashboard</NavLink>
        <NavLink to="/history" className={({isActive})=>`flex items-center gap-3 rounded-xl px-4 py-3 ${isActive?"bg-teal-50 text-teal-700":"text-slate-600 hover:bg-slate-50"}`}><ClipboardList size={18}/>Visit History</NavLink>
      </nav>
      <div className="absolute bottom-5 left-5 right-5 rounded-2xl bg-slate-50 p-4">
        <div className="flex items-center gap-3"><UserRound size={18}/><div><p className="font-semibold">{user.full_name}</p><p className="text-xs capitalize text-slate-500">{user.role}</p></div></div>
        <button onClick={logout} className="mt-4 flex w-full items-center gap-2 text-sm text-rose-600"><LogOut size={16}/>Sign out</button>
      </div>
    </aside>
    <main className="md:ml-64">
      <header className="sticky top-0 z-10 border-b bg-white/90 px-5 py-4 backdrop-blur md:px-8">
        <div className="flex items-center justify-between"><div><p className="text-sm text-slate-500">Good day,</p><h1 className="font-bold">{user.full_name}</h1></div><div className="rounded-full bg-teal-50 px-3 py-1 text-xs font-semibold capitalize text-teal-700">{user.role}</div></div>
      </header>
      <div className="p-5 md:p-8"><Routes><Route path="/" element={<DashboardPage user={user}/>}/><Route path="/history" element={<HistoryPage user={user}/>}/><Route path="*" element={<Navigate to="/" replace/>}/></Routes></div>
    </main>
  </div>;
}
