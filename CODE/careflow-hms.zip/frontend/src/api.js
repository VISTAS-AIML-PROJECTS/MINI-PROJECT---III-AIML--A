import axios from "axios";
const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || "http://127.0.0.1:8000" });
api.interceptors.request.use(config => {
  const token = sessionStorage.getItem("hms_token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});
api.interceptors.response.use(r => r, e => {
  if (e.response?.status === 401) sessionStorage.clear();
  return Promise.reject(e);
});
export default api;
