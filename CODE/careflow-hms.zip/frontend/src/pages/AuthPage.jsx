import { useState } from "react";
import { HeartPulse, LockKeyhole, Mail, UserRound } from "lucide-react";
import api from "../api";

const initial = {full_name:"",email:"",password:"",role:"patient",age:"",dob:"",gender:"",blood_group:"",phone:"",emergency_contact:"",department:"",specialization:""};

export default function AuthPage({onLogin}) {
  const [mode,setMode]=useState("login"); const [form,setForm]=useState(initial); const [error,setError]=useState(""); const [loading,setLoading]=useState(false);
  const set=(k,v)=>setForm({...form,[k]:v});
  const submit=async e=>{e.preventDefault();setError("");setLoading(true);try{const r=mode==="login"?await api.post("/auth/login",{email:form.email,password:form.password}):await api.post("/auth/signup",{...form,age:form.age?Number(form.age):null});onLogin(r.data)}catch(err){setError(err.response?.data?.detail||"Unable to complete request")}finally{setLoading(false)}};
  return <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-teal-50 via-white to-sky-50 p-4">
    <div className="grid w-full max-w-5xl overflow-hidden rounded-3xl border bg-white shadow-xl md:grid-cols-2">
      <div className="hidden bg-teal-700 p-10 text-white md:block"><HeartPulse size={42}/><h1 className="mt-8 text-4xl font-bold">CareFlow</h1><p className="mt-4 text-teal-100">A focused hospital workspace for patients, clinicians and staff.</p><div className="mt-10 space-y-3 text-sm text-teal-50"><p>✓ Secure JWT authentication</p><p>✓ Vitals and BMI tracking</p><p>✓ Clinical visit history</p><p>✓ Prescription records</p></div></div>
      <div className="p-6 md:p-10"><div className="mb-7 flex rounded-xl bg-slate-100 p-1"><button onClick={()=>setMode("login")} className={`flex-1 rounded-lg py-2 text-sm font-semibold ${mode==="login"?"bg-white shadow":"text-slate-500"}`}>Login</button><button onClick={()=>setMode("signup")} className={`flex-1 rounded-lg py-2 text-sm font-semibold ${mode==="signup"?"bg-white shadow":"text-slate-500"}`}>Sign Up</button></div>
      <h2 className="text-2xl font-bold">{mode==="login"?"Welcome back":"Create account"}</h2><p className="mt-1 text-sm text-slate-500">{mode==="login"?"Sign in to your clinical dashboard.":"Enter your hospital profile details."}</p>
      <form onSubmit={submit} className="mt-6 space-y-4">
        {mode==="signup"&&<><Field label="Full Name" value={form.full_name} onChange={v=>set("full_name",v)} required/><div className="grid grid-cols-2 gap-3"><Field label="Age" type="number" value={form.age} onChange={v=>set("age",v)}/><Field label="DOB" type="date" value={form.dob} onChange={v=>set("dob",v)}/></div><div className="grid grid-cols-2 gap-3"><Select label="Role" value={form.role} onChange={v=>set("role",v)} options={["patient","doctor","staff"]}/><Select label="Gender" value={form.gender} onChange={v=>set("gender",v)} options={["Male","Female","Other"]}/></div><div className="grid grid-cols-2 gap-3"><Select label="Blood Group" value={form.blood_group} onChange={v=>set("blood_group",v)} options={["A+","A-","B+","B-","AB+","AB-","O+","O-"]}/><Field label="Phone" value={form.phone} onChange={v=>set("phone",v)}/></div><Field label="Emergency Contact" value={form.emergency_contact} onChange={v=>set("emergency_contact",v)}/>{form.role!=="patient"&&<div className="grid grid-cols-2 gap-3"><Field label="Department" value={form.department} onChange={v=>set("department",v)}/>{form.role==="doctor"&&<Field label="Specialization" value={form.specialization} onChange={v=>set("specialization",v)}/>}</div>}</>}
        <Field label="Email" type="email" value={form.email} onChange={v=>set("email",v)} required/><Field label="Password" type="password" value={form.password} onChange={v=>set("password",v)} required/>
        {error&&<div className="rounded-xl bg-rose-50 p-3 text-sm text-rose-700">{error}</div>}
        <button disabled={loading} className="w-full rounded-xl bg-teal-700 py-3 font-semibold text-white hover:bg-teal-800 disabled:opacity-60">{loading?"Please wait…":mode==="login"?"Sign in":"Create account"}</button>
      </form></div>
    </div>
  </div>
}
function Field({label,value,onChange,type="text",required}){return <label className="block text-sm font-medium text-slate-700">{label}<input required={required} type={type} value={value} onChange={e=>onChange(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 focus:border-teal-500 focus:ring-2 focus:ring-teal-100"/></label>}
function Select({label,value,onChange,options}){return <label className="block text-sm font-medium text-slate-700">{label}<select value={value} onChange={e=>onChange(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5">{options.map(o=><option key={o} value={o}>{o}</option>)}</select></label>}
