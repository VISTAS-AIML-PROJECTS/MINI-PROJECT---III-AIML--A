Copy your own trained files into this folder:
- plant_disease_model.keras
- class_names.json

These files are not included in this GitHub starter ZIP.
