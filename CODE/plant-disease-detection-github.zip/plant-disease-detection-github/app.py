import os
from uuid import uuid4
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename
from predict import predict_image

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "uploads")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key")
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024  # 8 MB

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/scan", methods=["GET", "POST"])
def scan():
    if request.method == "GET":
        return render_template("scan.html")

    image = request.files.get("image")
    if not image or image.filename == "":
        flash("Please choose a leaf image.")
        return redirect(url_for("scan"))

    if not allowed_file(image.filename):
        flash("Please upload a PNG, JPG, JPEG, or WEBP image.")
        return redirect(url_for("scan"))

    extension = secure_filename(image.filename).rsplit(".", 1)[1].lower()
    filename = f"{uuid4().hex}.{extension}"
    image_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    image.save(image_path)

    try:
        predicted_class, confidence = predict_image(image_path)
    except FileNotFoundError as exc:
        os.remove(image_path)
        flash(str(exc))
        return redirect(url_for("scan"))
    except Exception as exc:
        os.remove(image_path)
        app.logger.exception("Prediction failed")
        flash(f"Prediction failed: {exc}")
        return redirect(url_for("scan"))

    return render_template(
        "result.html",
        image_url=url_for("static", filename=f"uploads/{filename}"),
        predicted_class=predicted_class,
        confidence=confidence
    )

@app.errorhandler(413)
def file_too_large(_error):
    flash("The image is too large. Maximum file size is 8 MB.")
    return redirect(url_for("scan"))

if __name__ == "__main__":
    app.run(debug=True)
