import json
import os
import numpy as np
import tensorflow as tf
from PIL import Image

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "model", "plant_disease_model.keras")
CLASS_NAMES_PATH = os.path.join(BASE_DIR, "model", "class_names.json")
IMAGE_SIZE = (224, 224)

_model = None
_class_names = None

def load_artifacts():
    global _model, _class_names

    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(
            "Trained model not found. Copy plant_disease_model.keras into the model/ folder."
        )
    if not os.path.exists(CLASS_NAMES_PATH):
        raise FileNotFoundError(
            "Class names not found. Copy class_names.json into the model/ folder."
        )

    if _model is None:
        _model = tf.keras.models.load_model(MODEL_PATH)

    if _class_names is None:
        with open(CLASS_NAMES_PATH, "r", encoding="utf-8") as file:
            _class_names = json.load(file)

    # Accept either a JSON list or a dictionary containing class names.
    if isinstance(_class_names, dict):
        _class_names = _class_names.get("class_names", _class_names.get("classes", list(_class_names.values())))

    return _model, _class_names

def prepare_image(image_path):
    image = Image.open(image_path).convert("RGB")
    image = image.resize(IMAGE_SIZE)
    image_array = np.asarray(image, dtype=np.float32)

    # IMPORTANT:
    # This example uses pixel scaling to [0, 1].
    # Change this preprocessing to exactly match the preprocessing used
    # when your model was trained. For MobileNetV2 preprocess_input,
    # use: tf.keras.applications.mobilenet_v2.preprocess_input(image_array)
    image_array = image_array / 255.0

    return np.expand_dims(image_array, axis=0)

def predict_image(image_path):
    model, class_names = load_artifacts()
    input_array = prepare_image(image_path)
    predictions = model.predict(input_array, verbose=0)[0]

    predicted_index = int(np.argmax(predictions))
    if predicted_index >= len(class_names):
        raise ValueError("The model output count does not match class_names.json.")

    predicted_class = str(class_names[predicted_index])
    confidence = float(predictions[predicted_index]) * 100.0
    return predicted_class, round(confidence, 2)
